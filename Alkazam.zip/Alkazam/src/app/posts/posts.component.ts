import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {
  newPost;
  allPosts = [];
  data;
  posts = [];
  constructor(private route: Router, private dataService: DataService) { }

  ngOnInit() {
  var userId = localStorage.getItem("userId");
  var userDetails = JSON.parse(localStorage.getItem("userDetails"+userId));
   if(localStorage.getItem("userDetails"+userId) != undefined){
     var allData = JSON.parse(localStorage.getItem("userDetails"+userId));
      this.allPosts = allData[1];
   }
  }

  addPost() {
    var userId = localStorage.getItem("userId");
    var allData = [];
    if (localStorage.getItem("userDetails" + userId) == undefined) {
      var postData = this.newPost;      
      var posts = [];
      posts.push(postData)
      allData.push(userId);
      allData.push(posts);
      localStorage.setItem("userDetails" + userId, JSON.stringify(allData));
      this.data = JSON.parse(localStorage.getItem("userDetails"+userId));
      this.allPosts = this.data[1];
      console.log("this.allPosts if : "+this.allPosts);
    }
    else{
      var userDetails = JSON.parse(localStorage.getItem("userDetails"+userId));
      if(userDetails[0] == localStorage.getItem("userId")){
       this.posts = userDetails[1];
       this.posts.push(this.newPost);
       this.allPosts = this.posts;
       var currentPostData = [];
       currentPostData.push(userDetails[0]);
       currentPostData.push(this.posts);
       localStorage.setItem("userDetails"+userId, JSON.stringify(currentPostData));
      }
      
      console.log("this.allPosts else : "+this.allPosts);
    }
    this.newPost = "";
  }

  logout(){
    this.dataService.isUserLoggedIn(false);
    this.route.navigate(['']);
  }
 
}
