import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userEmail;
  constructor(private route: Router, private dataService: DataService) { }

  ngOnInit() {
    let userId = localStorage.getItem("userId");
    
    var isLoggedIn;
    this.dataService.isLoggedIn.subscribe(isUserLoggedIn => isLoggedIn = isUserLoggedIn);
    console.log("ngOnInit isLoggedIn : ",isLoggedIn);
    if (userId != undefined && isLoggedIn) {
      this.route.navigate(['posts']);
    }
    else{
      this.route.navigate([''])
    }
  }

  login() {
    console.log(localStorage.getItem('userId'))
    if (localStorage.getItem('userId') != undefined && this.userEmail == localStorage.getItem('userId')) {
      this.dataService.isUserLoggedIn(true);
      this.route.navigate(['posts']);
    }
    else {
      this.route.navigate([''])
    }

  }
}
