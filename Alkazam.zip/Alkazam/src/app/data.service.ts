import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class DataService {

  private messageSource = new BehaviorSubject(false);
  isLoggedIn = this.messageSource.asObservable();

  constructor() { }

  isUserLoggedIn(isLoggedIn: boolean) {
    this.messageSource.next(isLoggedIn)
  }

}